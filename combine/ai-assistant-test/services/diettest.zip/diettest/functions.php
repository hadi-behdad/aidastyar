
<?php
// ثبت سرویس رژیم غذایی
function ai_assistant_register_diettest_service() {
    $service_manager = AI_Assistant_Service_Manager::get_instance();
    
    if (!$service_manager->get_service('diettest')) {
        $service_manager->register_service([
            'id' => 'diettest',
            'name' => __('رژیم غذایی هوشمند', 'ai-assistant'),
            'description' => __('طراحی برنامه غذایی بر اساس مشخصات فردی', 'ai-assistant'),
            'price' => 15000,
            'icon' => 'dashicons-carrot',
            'template' => get_template_directory() . '/services/diettest/template-parts/form.php',
            'active' => true
        ]);
    }
    
    // ثبت هوک‌های AJAX
    add_action('wp_ajax_ai_assistant_diettest', 'ai_assistant_handle_diettest_request');
    add_action('wp_ajax_nopriv_ai_assistant_diettest', 'ai_assistant_handle_unauthorized');
}
add_action('after_setup_theme', 'ai_assistant_register_diettest_service');





